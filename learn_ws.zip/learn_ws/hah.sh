#!/bin/bash
source /home/lc/2022HPX/learn_ws/devel/setup.bash
roslaunch simplebb main2.launch 
roslaunch simplebb amcl.launch
