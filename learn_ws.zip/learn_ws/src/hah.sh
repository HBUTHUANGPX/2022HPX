#!/bin/sh
source ~/2022hpx/learn_ws/devel/setup.bash